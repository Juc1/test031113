<?php
function ioptus_o4_111213_form_alter(&$form, &$form_state, $form_id) {
  if ($form_id == 'search_block_form') {
    $form['search_block_form']['#title'] = t('Searchio'); // Change the text on the label element
    $form['search_block_form']['#title_display'] = 'invisible'; // Toggle label visibilty
    $form['search_block_form']['#size'] = 1;  // define size of the textfield
    $form['search_block_form']['#default_value'] = t('Search iOptus.com...'); // Set a default value for the textfield
    $form['actions']['submit']['#value'] = t('GO!'); // Change the text on the submit button
     $form['actions']['submit'] = array('#type' => 'image_button', '#src' => base_path() . path_to_theme() . '/images/search-button.png');    // Add extra attributes to the text box
    $form['search_block_form']['#attributes']['onblur'] = "if (this.value == '') {this.value = 'Search';}";
    $form['search_block_form']['#attributes']['onfocus'] = "if (this.value == 'Search iOptus.com...') {this.value = '';}";
    // Prevent user from searching the default text
    $form['#attributes']['onsubmit'] = "if(this.search_block_form.value=='Search'){ alert('Please enter a search'); return false; }";

    // Alternative (HTML5) placeholder attribute instead of using the javascript
    $form['search_block_form']['#attributes']['placeholder'] = t('Search');
  }
} 

function ioptus_o4_111213_preprocess_html(&$variables){
// This function looks for node 1 and only adds the javascript for this.
// However it can be extended in different ways if required
    drupal_add_library('system', 'ui.tabs');
    drupal_add_js('jQuery(document).ready(function(){
                jQuery("#tabs-1, #tabs-2, #tabs-3, #tabs-4").tabs({event: "click"});
                jQuery("#tabs-1, #tabs-2, #tabs-3, #tabs-4").tabs().addClass("ui-tabs-vertical ui-helper-clearfix");
                jQuery("#tabs-1 li, #tabs-2 li, #tabs-3 li, #tabs-4 li").removeClass("ui-corner-top").addClass("ui-corner-left");
            });',
        'inline');
}
